import React from 'react';
import {MoveUpButton, MoveDownButton, DeleteButton, DoneButton} 
    from './Buttons.js';
import {Row,Col} from 'react-bootstrap';

export class ListLine extends React.Component {
    constructor(props){
      super(props);
      this.moveMeUp = this.moveMeUp.bind(this);
      this.moveMeDown = this.moveMeDown.bind(this);
      this.deleteMe = this.deleteMe.bind(this);
      this.makeMeDone = this.makeMeDone.bind(this);
    }
  
    moveMeUp(){
      this.props.moveUp(this.props.index);
    }
  
    moveMeDown(){
      this.props.moveDown(this.props.index);
    }
  
    deleteMe(){
      this.props.delete(this.props.index);
    }
  
    makeMeDone(){
      this.props.done(this.props.index);
    }
  
    render(){
      var styles;
      if (this.props.task.done === true){
        styles = {textDecoration: 'line-through'}
      }
      return (
        <Row>
          <Col xs='2' sm ='4' md='6' lg='6' style = {styles}>
            {this.props.task.text}
          </Col>
          <Col >
            <MoveUpButton onClick = {this.moveMeUp}/>
          </Col>
          <Col >
            <MoveDownButton onClick = {this.moveMeDown}/>
          </Col>
          <Col >
            <DoneButton onClick = {this.makeMeDone}/>
          </Col>
          <Col >
            <DeleteButton onClick = {this.deleteMe}/>
          </Col>
        </Row>
        );
    }
  
  }