import React from 'react';
import Button from 'react-bootstrap/Button';


export class MoveUpButton extends React.Component{
    render(){
      return (<Button variant="primary" block onClick = {this.props.onClick}>up</Button>);
    }
  }
  
export class MoveDownButton extends React.Component{
    render(){
      return (<Button variant="info" block onClick = {this.props.onClick}>down</Button>);
    }
  }
  
export class DoneButton extends React.Component{
    render(){
      return (<Button variant="success" block onClick = {this.props.onClick}>Done</Button>);
    }
  }
  
export class DeleteButton extends React.Component{
    render(){
      return (<Button variant="danger" block onClick = {this.props.onClick}>Delete</Button>);
    }
  }