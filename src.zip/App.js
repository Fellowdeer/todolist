import React from 'react';
import {Container} from 'react-bootstrap';
import {ListLine} from './ListLine.js';
import {NewTask} from './NewTask.js';




class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      tasks: [{text: "testask1", done: false},{text: "testask2", done: false},
    {text: "testask3", done: false},{text: "testask4", done: false}]
    }
    this.moveTaskUp = this.moveTaskUp.bind(this);
    this.moveTaskDown = this.moveTaskDown.bind(this);
    this.taskDelete = this.taskDelete.bind(this);
    this.taskDone = this.taskDone.bind(this);
    this.addTask = this.addTask.bind(this);
  }

  moveTaskUp(index){
    var helper;
    var helptasks = this.state.tasks;
    if (index > 0) {
      helper = helptasks[index-1];
      helptasks[index-1] = helptasks[index];
      helptasks[index] = helper;
      this.setState({tasks: helptasks});
    }
  }

  moveTaskDown(index){
    var helper;
    var helptasks = this.state.tasks;
    if (index < (helptasks.length-1)) {
      helper = helptasks[index+1];
      helptasks[index+1] = helptasks[index];
      helptasks[index] = helper;
      this.setState({tasks: helptasks});
    }
  }

  taskDone(index){
    var helptasks = this.state.tasks;
    if (helptasks[index].done === false){
      helptasks[index].done = true
    }
    else {
      helptasks[index].done = false
    }

    this.setState({tasks: helptasks});

  }

  taskDelete(index){
      var helptasks = this.state.tasks;
      helptasks.splice(index,1);
      this.setState({tasks: helptasks});
  }

  addTask(text){
    var helptasks = this.state.tasks;
    helptasks.push({text: text, done: false});
    this.setState({tasks: helptasks});
  }

  render(){
    var list = [];
    var i;
    for (i = 0; i < this.state.tasks.length; i++) {
        list.push(<ListLine
          index = {i}
          task = {this.state.tasks[i]}
          moveUp = {this.moveTaskUp}
          moveDown = {this.moveTaskDown}
          delete = {this.taskDelete}
          done = {this.taskDone}
          />);
      }
    return (
      <Container fluid>
      <ul>{list}</ul>
      <NewTask add = {this.addTask}/>
      </Container>);
  }
}
export default App;
