import React from 'react';
import {Row,Col,Button} from 'react-bootstrap';

export class NewTask extends React.Component{
    constructor(props){
      super(props);
      this.state = {value: "new task here"};
  
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleSubmit(event){
      this.props.add(this.state.value);
      this.setState({value: "new task here"});
    }
  
    handleChange(event){
      this.setState({value: event.target.value})
    }
  
    render(){
      return (
        <div>
          <Row>
            <Col xs='8' sm ='8' md='10' lg='10'>
            <form onSubmit={this.handleSubmit}>
              <label>
                <textarea cols="50"    value={this.state.value} onChange={this.handleChange} />
              </label>
            </form>
            </Col>
            <Col xs='4' sm ='4' md='2' lg='2'>
              <Button variant="light" onClick = {this.handleSubmit}>Add Task</Button>
            </Col>
          </Row>
        </div>);
        
    }
  }